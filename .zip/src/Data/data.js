// const pre=`http://localhost:2979/`; 
// const pre = `http://148.251.88.109:8080/EconetBigCash/`;
const pre = `https://api.econetbigcash.com/`;
// const pre=`http://5.189.166.187:5551/BigcashPortalLive/`;
// const pre=`http://91.205.172.123:2979/`


const sendServicesDataApi=`${pre}sendServicesData`;
export{sendServicesDataApi};

const  sendWinnersApi=`${pre}sendWinnersNew`;
export{sendWinnersApi};

const sendPrizesApi=`${pre}sendPrizes`;
export{sendPrizesApi};

const sendScoreApi=`${pre}sendScore`;
export{sendScoreApi};

const sendTermsApi=`${pre}sendTerms`;
export{sendTermsApi};

const bigcashImgUrl=`https://www.gameninja.in/html/BigcashPortalData/BigCash.png`;
export{bigcashImgUrl};

const price=`${pre}price`;
export{price};

const loginUser=`${pre}loginUser`;
export{loginUser};

const checkUser=`${pre}checkUser`;
export{checkUser};

const subscribeUser=`${pre}subRequest`
export{subscribeUser};

const matchOtp=`${pre}matchOtp`;
export{matchOtp};

const google_key=`G-6243J8J93N`;
export {google_key}

